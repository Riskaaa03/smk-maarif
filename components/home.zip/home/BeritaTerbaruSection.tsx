'use client'

import Link from 'next/link'
import Image from 'next/image'

interface BeritaItem {
  id: number
  judul: string
  slug: string
  ringkasan: string
  kategori: string
  thumbnail_url: string | null
  tanggal_publikasi: string
  views: number
}

interface BeritaTerbaruSectionProps {
  articles: BeritaItem[]
}

function formatTanggal(dateString: string): string {
  const date = new Date(dateString)
  return date.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  })
}

function getKategoriBadge(kategori: string): string {
  switch (kategori) {
    case 'berita':
      return 'bg-blue-100 text-blue-700'
    case 'pengumuman':
      return 'bg-yellow-100 text-yellow-700'
    case 'prestasi':
      return 'bg-nu-green-100 text-nu-green-700'
    case 'kegiatan':
      return 'bg-purple-100 text-purple-700'
    default:
      return 'bg-gray-100 text-gray-700'
  }
}

function getKategoriIcon(kategori: string): string {
  switch (kategori) {
    case 'berita':
      return '📰'
    case 'pengumuman':
      return '📢'
    case 'prestasi':
      return '🏆'
    case 'kegiatan':
      return '📅'
    default:
      return '📰'
  }
}

export default function BeritaTerbaruSection({ articles }: BeritaTerbaruSectionProps) {
  // Jika belum ada data
  if (!articles || articles.length === 0) {
    return (
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <span className="inline-block text-sm font-semibold text-nu-green-600 uppercase tracking-wider mb-2">
              Update Terkini
            </span>
            <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl md:text-4xl">
              Berita Terbaru
            </h2>
            <p className="mt-2 text-gray-500">Belum ada berita. Silakan cek lagi nanti.</p>
          </div>
          <div className="text-center py-10 bg-gray-50 rounded-xl">
            <p className="text-gray-500">📰 Belum ada berita untuk ditampilkan</p>
            <Link href="/admin/berita" className="text-nu-green-600 text-sm mt-2 inline-block">
              Tambah berita sekarang →
            </Link>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-2xl font-bold text-gray-900 sm:text-3xl md:text-4xl">
            Berita Terbaru
          </h2>
          <p className="mt-2 text-gray-600 max-w-xl mx-auto">
            Informasi terbaru seputar kegiatan, prestasi, dan pengumuman dari SMK Ma'arif NU 01 Karangkobar
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {articles.map((article) => (
            <Link
              key={article.id}
              href={`/berita/${article.slug}`}
              className="group bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              {/* Thumbnail */}
              <div className="relative h-48 overflow-hidden bg-gray-100">
                {article.thumbnail_url ? (
                  <Image
                    src={article.thumbnail_url}
                    alt={article.judul}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
                    <span className="text-5xl opacity-50">{getKategoriIcon(article.kategori)}</span>
                  </div>
                )}
                
                {/* Kategori Badge */}
                <div className="absolute top-3 left-3">
                  <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full ${getKategoriBadge(article.kategori)}`}>
                    {getKategoriIcon(article.kategori)} {article.kategori}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs text-gray-400">
                    📅 {formatTanggal(article.tanggal_publikasi)}
                  </span>
                </div>
                
                <h3 className="font-bold text-gray-800 text-base md:text-lg mb-2 line-clamp-2 group-hover:text-nu-green-600 transition-colors">
                  {article.judul}
                </h3>
                
                <p className="text-gray-500 text-sm mb-3 line-clamp-2">
                  {article.ringkasan}
                </p>
                
                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span className="flex items-center gap-1">
                    👁️ {article.views} dilihat
                  </span>
                  <span className="text-nu-green-600 group-hover:translate-x-1 transition-transform">
                    Baca selengkapnya →
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-8">
          <Link
            href="/berita"
            className="inline-flex items-center gap-2 text-nu-green-600 hover:text-nu-green-700 font-medium"
          >
            Lihat Semua Berita
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  )
}
