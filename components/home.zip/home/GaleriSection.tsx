'use client'

import Link from 'next/link'
import Image from 'next/image'

interface GaleriItem {
  id: number
  title: string
  description: string
  imageUrl: string
  date: string
}

interface GaleriSectionProps {
  items: GaleriItem[]
}

export default function GaleriSection({ items }: GaleriSectionProps) {
  if (!items || items.length === 0) {
    return (
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <p className="mb-1.5 flex items-center gap-2 text-[11px] font-medium uppercase tracking-[.12em] text-nu-green-500">
              <span className="block h-px w-5 bg-nu-green-300" aria-hidden="true" />
              Dokumentasi
            </p>
            <h2 className="text-2xl font-bold text-nu-green-900">Galeri Kegiatan</h2>
            <p className="text-nu-green-600 mt-2 text-sm">Belum ada foto. Upload foto pertama di admin panel!</p>
          </div>
          <div className="text-center py-10 bg-nu-green-50 rounded-2xl border border-nu-green-100">
            <p className="text-nu-green-400 text-sm">Tidak ada foto untuk ditampilkan</p>
            <Link href="/admin/galeri" className="text-nu-green-600 text-sm mt-2 inline-block hover:text-nu-green-800 hover:underline transition-colors">
              Upload foto sekarang →
            </Link>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-12 md:py-16 bg-white" aria-labelledby="galeri-heading">
      <div className="container mx-auto px-4">
        {/* Section header */}
        <div className="mb-10">
          <p className="mb-1.5 flex items-center gap-2 text-[11px] font-medium uppercase tracking-[.12em] text-nu-green-500">
            <span className="block h-px w-5 bg-nu-green-300" aria-hidden="true" />
            Dokumentasi
          </p>
          <h2 id="galeri-heading" className="text-2xl font-bold text-nu-green-900 mb-1 tracking-tight">
            Galeri Kegiatan
          </h2>
          <p className="text-nu-green-700/60 text-sm max-w-lg">
            Dokumentasi kegiatan terbaru SMK Ma&apos;arif NU 01 Karangkobar
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((item) => (
            <div
              key={item.id}
              className="group bg-white rounded-2xl overflow-hidden border border-nu-green-100 hover:border-nu-green-200 hover:-translate-y-0.5 hover:shadow-md transition-all duration-200"
            >
              <div className="relative h-52 overflow-hidden bg-nu-green-50">
                <Image
                  src={item.imageUrl}
                  alt={item.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                {/* Subtle gradient overlay bawah untuk keterbacaan */}
                <div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-nu-green-900/20 to-transparent" />
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-nu-green-900 text-sm line-clamp-1">{item.title}</h3>
                {item.description && (
                  <p className="text-xs text-nu-green-700/55 mt-1 line-clamp-2 leading-relaxed">{item.description}</p>
                )}
                <div className="flex items-center justify-between mt-3">
                  <p className="text-[11px] text-nu-green-400">{item.date}</p>
                  <span className="text-[11px] font-medium text-nu-green-600 group-hover:text-nu-green-800 transition-colors flex items-center gap-0.5">
                    Lihat
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer link */}
        <div className="mt-10 flex items-center gap-3">
          <span className="h-px flex-1 bg-nu-green-100" aria-hidden="true" />
          <Link
            href="/galeri"
            className="inline-flex items-center gap-2 rounded-full border border-nu-green-200 bg-white px-5 py-2 text-[13px] font-medium text-nu-green-700 hover:bg-nu-green-50 hover:border-nu-green-300 hover:text-nu-green-900 transition-colors"
          >
            Lihat Semua Galeri
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
          <span className="h-px flex-1 bg-nu-green-100" aria-hidden="true" />
        </div>
      </div>
    </section>
  )
}
