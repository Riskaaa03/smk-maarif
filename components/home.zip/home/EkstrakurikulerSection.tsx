interface EkstrakurikulerSectionProps {
  items?: string[]
}

const DEFAULT_EKSKUL: string[] = [
  'Pramuka',
  'PMR (Palang Merah Remaja)',
  'Futsal',
  'Bola Voli',
  'Mapala',
  'Pagar Nusa',
]

// SVG inline — tidak terlihat AI, lebih bersih dari emoji
const EKSKUL_ICONS: Record<string, React.ReactNode> = {
  Pramuka: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3L4 20h16L12 3z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v17M8 14h8" />
    </svg>
  ),
  'PMR (Palang Merah Remaja)': (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16M4 12h16" />
      <rect x="3" y="3" width="18" height="18" rx="3" strokeLinecap="round" />
    </svg>
  ),
  Futsal: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-6 h-6">
      <circle cx="12" cy="12" r="9" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3c0 4-2 6-2 9s2 5 2 9M3 12c4 0 6-2 9-2s5 2 9 2" />
    </svg>
  ),
  'Bola Voli': (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-6 h-6">
      <circle cx="12" cy="12" r="9" />
      <path strokeLinecap="round" d="M3.5 9.5C6 8 9 9 12 8s5-3 7.5-2" />
      <path strokeLinecap="round" d="M3.5 14.5C6 16 9 15 12 16s5 3 7.5 2" />
      <line x1="12" y1="3" x2="12" y2="21" strokeLinecap="round" />
    </svg>
  ),
  Mapala: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 20L9 8l4 6 3-4 5 10H3z" />
    </svg>
  ),
  'Pagar Nusa': (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l2 5h5l-4 3 1.5 5L12 13l-4.5 3L9 11 5 8h5l2-5z" />
    </svg>
  ),
}

const EKSKUL_DESCRIPTIONS: Record<string, string> = {
  Pramuka: 'Kegiatan kepramukaan yang membentuk karakter, kedisiplinan, dan jiwa kepemimpinan',
  'PMR (Palang Merah Remaja)': 'Organisasi kemanusiaan yang melatih pertolongan pertama dan kepedulian sosial',
  Futsal: 'Olahraga futsal untuk mengembangkan kerja sama tim dan sportivitas',
  'Bola Voli': 'Olahraga bola voli untuk melatih koordinasi dan kekuatan fisik',
  Mapala: 'Pecinta alam yang aktif dalam kegiatan konservasi dan penjelajahan',
  'Pagar Nusa': 'Seni bela diri tradisional pencak silat untuk melatih fisik dan mental',
}

function getIcon(nama: string): React.ReactNode {
  return EKSKUL_ICONS[nama] ?? (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-6 h-6">
      <circle cx="12" cy="12" r="9" />
      <path strokeLinecap="round" d="M12 8v4l3 3" />
    </svg>
  )
}

function getDescription(nama: string): string {
  return EKSKUL_DESCRIPTIONS[nama] ?? 'Kegiatan ekstrakurikuler untuk mengembangkan bakat dan minat siswa'
}

export default function EkstrakurikulerSection({ items }: EkstrakurikulerSectionProps) {
  const ekskul = items && items.length > 0 ? items : DEFAULT_EKSKUL

  return (
    <section
      aria-labelledby="ekstrakurikuler-heading"
      className="py-12 md:py-16 bg-white"
    >
      <div className="container mx-auto px-4">
        <div className="mb-10 md:mb-12">
          <p className="mb-1.5 flex items-center gap-2 text-[11px] font-medium uppercase tracking-[.12em] text-nu-green-500">
            <span className="block h-px w-5 bg-nu-green-300" aria-hidden="true" />
            Kegiatan Siswa
          </p>
          <h2
            id="ekstrakurikuler-heading"
            className="text-2xl font-bold text-nu-green-900 sm:text-3xl"
          >
            Ekstrakurikuler
          </h2>
          <p className="mt-2 text-nu-green-700/70 text-sm max-w-lg">
            Kembangkan bakat dan minatmu melalui berbagai kegiatan ekstrakurikuler yang kami sediakan.
          </p>
        </div>

        <ul
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 md:gap-4"
          aria-label="Daftar ekstrakurikuler"
        >
          {ekskul.map((nama) => (
            <li key={nama}>
              <div className="group flex flex-col gap-3 p-4 rounded-xl border border-nu-green-100 bg-nu-green-50 hover:border-nu-green-200 hover:bg-nu-green-100/50 hover:-translate-y-0.5 transition-all duration-150 h-full cursor-default">
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-lg bg-white text-nu-green-700 border border-nu-green-100"
                  aria-hidden="true"
                >
                  {getIcon(nama)}
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-nu-green-900 leading-snug mb-1">
                    {nama}
                  </h3>
                  <p className="text-xs text-nu-green-700/60 leading-relaxed line-clamp-2">
                    {getDescription(nama)}
                  </p>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}