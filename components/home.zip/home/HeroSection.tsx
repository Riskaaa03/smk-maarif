import Link from 'next/link'
import Image from 'next/image'
import fotoSekolah from './image/foto_sekolah.png'

/**
 * Komponen Hero Section untuk halaman beranda.
 * Menampilkan judul selamat datang, tagline Islam NU, dan dua tombol CTA.
 *
 * Background menggunakan gradient hijau NU sebagai fallback (sebelum foto nyata tersedia).
 * Mendukung prop `backgroundImage` untuk foto sekolah di masa mendatang.
 */
interface HeroSectionProps {
  /** URL foto background sekolah. Jika tidak ada, gradient hijau NU digunakan sebagai fallback. */
  backgroundImage?: string
}

export default function HeroSection({ backgroundImage }: HeroSectionProps) {
  const imageToUse = backgroundImage || fotoSekolah.src
  return (
    <section
      aria-label="Hero beranda SMK Ma'arif NU 01 Karangkobar"
      className="relative flex items-center justify-center min-h-[500px] md:min-h-screen overflow-hidden"
    >
      {/* Background: foto dengan overlay atau gradient fallback */}
      <div className="absolute inset-0">
        <Image
          src={imageToUse}
          alt="SMK Ma'arif NU 01 Karangkobar"
          fill
          className="object-cover"
          priority
        />
        {/* Overlay semi-transparan hijau NU */}
        <div
          className="absolute inset-0 bg-nu-green-900/80"
          aria-hidden="true"
        />
      </div>

      {/* Pola dekoratif — overlay tipis untuk tekstur */}
      <div
        className="absolute inset-0 opacity-10 z-0"
        style={{
          backgroundImage:
            'radial-gradient(circle at 25% 25%, white 1px, transparent 1px), radial-gradient(circle at 75% 75%, white 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }}
        aria-hidden="true"
      />

      {/* Konten utama */}
      <div className="relative z-10 container mx-auto px-4 py-16 text-center text-white">
        {/* Badge identitas NU */}
        <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-1.5 mb-6 text-sm font-medium text-white/90">
          
        </div>

        {/* Judul utama */}
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl lg:text-6xl drop-shadow-lg max-w-4xl mx-auto leading-tight">
          Selamat Datang di{' '}
          <span className="text-nu-gold-300">SMK Ma&apos;arif NU 01</span>{' '}
          Karangkobar
        </h1>

        {/* Tagline Islam NU */}
        <p className="mt-6 text-base sm:text-lg md:text-xl text-white/90 max-w-2xl mx-auto leading-relaxed drop-shadow">
          Membentuk Generasi Muslim yang Kompeten, Berakhlak Mulia, dan
          Berdaya Saing
        </p>

        {/* Tombol CTA */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          {/* CTA Utama: PPDB */}
          <Link
            href="/ppdb"
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-nu-gold-400 hover:bg-nu-gold-300 text-nu-green-900 font-semibold px-8 py-3.5 text-base transition-colors duration-200 shadow-lg hover:shadow-xl focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-nu-gold-300 w-full sm:w-auto sm:min-w-[220px]"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
              className="w-5 h-5 shrink-0"
              aria-hidden="true"
            >
              <path d="M10.75 4.75a.75.75 0 0 0-1.5 0v4.5h-4.5a.75.75 0 0 0 0 1.5h4.5v4.5a.75.75 0 0 0 1.5 0v-4.5h4.5a.75.75 0 0 0 0-1.5h-4.5v-4.5Z" />
            </svg>
            Daftar PPDB Sekarang
          </Link>

          {/* CTA Sekunder: Program Keahlian */}
          <Link
            href="/program-keahlian"
            className="inline-flex items-center justify-center gap-2 rounded-lg border-2 border-white/70 hover:border-white bg-white/10 hover:bg-white/20 text-white font-semibold px-8 py-3.5 text-base transition-colors duration-200 backdrop-blur-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white w-full sm:w-auto sm:min-w-[220px]"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
              className="w-5 h-5 shrink-0"
              aria-hidden="true"
            >
              <path d="M10.394 2.08a1 1 0 0 0-.788 0l-7 3a1 1 0 0 0 0 1.84L5.25 8.051a.999.999 0 0 1 .356-.257l4-1.714a1 1 0 1 1 .788 1.838L7.667 9.088l1.94.831a1 1 0 0 0 .787 0l7-3a1 1 0 0 0 0-1.838l-7-3ZM3.31 9.397 5 10.12v4.102a8.969 8.969 0 0 0-1.05-.174 1 1 0 0 1-.89-.89 11.115 11.115 0 0 1 .25-3.762Zm5.99 7.176A9.026 9.026 0 0 0 7 14.935v-3.957l1.818.78a3 3 0 0 0 2.364 0l5.508-2.361a11.026 11.026 0 0 1 .25 3.762 1 1 0 0 1-.89.89 8.968 8.968 0 0 0-5.35 2.524 1 1 0 0 1-1.4 0ZM6 18a1 1 0 0 0 1-1v-2.065a8.935 8.935 0 0 0-2-.712V17a1 1 0 0 0 1 1Z" />
            </svg>
            Pelajari Program Keahlian
          </Link>
        </div>

        {/* Info singkat program keahlian */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-white/75">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-nu-gold-400 shrink-0" aria-hidden="true" />
            Teknik &amp; Bisnis Sepeda Motor (TBSM)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-nu-gold-400 shrink-0" aria-hidden="true" />
            Teknik Jaringan Komputer &amp; Telekomunikasi (TJKT)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-nu-gold-400 shrink-0" aria-hidden="true" />
            Akuntansi &amp; Keuangan Lembaga (AKL)
          </span>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-white/50 animate-bounce"
        aria-hidden="true"
      >
        <span className="text-xs tracking-widest uppercase">Scroll</span>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 20 20"
          fill="currentColor"
          className="w-4 h-4"
        >
          <path
            fillRule="evenodd"
            d="M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z"
            clipRule="evenodd"
          />
        </svg>
      </div>
    </section>
  )
}
