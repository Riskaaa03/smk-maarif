import Link from "next/link";
import Image from "next/image";
import LogoTBSM from "./image/Logo_TBSM.png";
import LogoTJKT from "./image/Logo_TJKT.png";
import LogoAKL from "./image/Logo_Akuntansi.png";

interface ProgramCard {
  kode: "tbsm" | "tjkt" | "akl";
  namaLengkap: string;
  deskripsi: string;
  logoUrl: any;
  accentClass: string;
  badgeClass: string;
  dotColor: string;
}

const programs: ProgramCard[] = [
  {
    kode: "tbsm",
    namaLengkap: "Teknik & Bisnis Sepeda Motor",
    deskripsi:
      "Membekali peserta didik agar mampu berkarir dan profesional dalam perawatan, perbaikan mesin, transmisi, kelistrikan, dan pengelasan.",
    logoUrl: LogoTBSM,
    accentClass: "border-t-nu-green-600",
    badgeClass: "bg-nu-green-100 text-nu-green-800",
    dotColor: "bg-nu-green-500",
  },
  {
    kode: "tjkt",
    namaLengkap: "Teknik Jaringan Komputer & Telekomunikasi",
    deskripsi:
      "Membekali peserta didik dalam bidang pemrograman, jaringan komputer, mikrotik, desain grafis, dan networking.",
    logoUrl: LogoTJKT,
    accentClass: "border-t-nu-green-500",
    badgeClass: "bg-nu-green-100 text-nu-green-800",
    dotColor: "bg-nu-green-400",
  },
  {
    kode: "akl",
    namaLengkap: "Akuntansi & Keuangan Lembaga",
    deskripsi:
      "Menghasilkan lulusan yang memiliki kompetensi, integritas, dan kecakapan kerja dalam bidang akuntansi serta keuangan lembaga.",
    logoUrl: LogoAKL,
    accentClass: "border-t-nu-green-400",
    badgeClass: "bg-nu-green-100 text-nu-green-800",
    dotColor: "bg-nu-green-300",
  },
];

export default function ProgramKeahlianSection() {
  return (
    <section
      aria-labelledby="program-keahlian-heading"
      className="py-14 md:py-20 bg-white"
    >
      <div className="container mx-auto px-4">
        {/* Heading */}
        <div className="text-center mb-12">
          <span className="inline-flex items-center gap-1.5 text-[11px] font-bold tracking-widest uppercase text-nu-green-600 bg-nu-green-50 border border-nu-green-100 px-3 py-1.5 rounded-full mb-4">
            <span className="block h-1 w-1 rounded-full bg-nu-green-500" aria-hidden="true" />
            Jurusan Kami
          </span>
          <h2
            id="program-keahlian-heading"
            className="text-2xl md:text-3xl font-bold text-nu-green-900 tracking-tight"
          >
            Program Keahlian
          </h2>
          <p className="mt-2 max-w-xl mx-auto text-sm md:text-[15px] leading-7 text-nu-green-700/70">
            Pilih program yang sesuai dengan minat dan cita-citamu. Kami
            mempersiapkan peserta didik agar siap bekerja, kuliah, maupun
            berwirausaha.
          </p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {programs.map((program) => (
            <article
              key={program.kode}
              className={`group flex flex-col overflow-hidden rounded-2xl border border-nu-green-100 bg-white shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-200 border-t-4 ${program.accentClass}`}
            >
              <div className="flex flex-col items-center text-center gap-4 p-6 flex-1">
                {/* Logo */}
                <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-nu-green-50 border border-nu-green-100 shadow-sm">
                  <Image
                    src={program.logoUrl}
                    alt={program.namaLengkap}
                    width={44}
                    height={44}
                    className="object-contain"
                  />
                </div>

                <div>
                  <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-bold tracking-wide ${program.badgeClass}`}>
                    <span className={`block h-1.5 w-1.5 rounded-full ${program.dotColor}`} aria-hidden="true" />
                    {program.kode.toUpperCase()}
                  </span>
                  <h3 className="mt-2 text-sm font-semibold leading-snug text-nu-green-900">
                    {program.namaLengkap}
                  </h3>
                </div>

                <p className="text-xs leading-relaxed text-nu-green-700/60 flex-1">
                  {program.deskripsi}
                </p>

                <Link
                  href={`/program-keahlian/${program.kode}`}
                  className="mt-1 inline-flex items-center justify-center gap-2 rounded-xl bg-nu-green-600 hover:bg-nu-green-700 text-white px-5 py-2.5 text-xs font-semibold transition-colors duration-150 w-full"
                >
                  Selengkapnya
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="h-3.5 w-3.5">
                    <path fillRule="evenodd" d="M3 10a.75.75 0 0 1 .75-.75h10.638L10.23 5.29a.75.75 0 1 1 1.04-1.08l5.5 5.25a.75.75 0 0 1 0 1.08l-5.5 5.25a.75.75 0 1 1-1.04-1.08l4.158-3.96H3.75A.75.75 0 0 1 3 10Z" clipRule="evenodd" />
                  </svg>
                </Link>
              </div>
            </article>
          ))}
        </div>

        {/* Footer link */}
        <div className="text-center mt-8">
          <Link
            href="/program-keahlian"
            className="inline-flex items-center gap-1.5 text-sm text-nu-green-600 font-medium hover:text-nu-green-800 transition-colors duration-150"
          >
            Lihat semua program keahlian
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  );
}
