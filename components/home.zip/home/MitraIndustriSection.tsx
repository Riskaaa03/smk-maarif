'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import Link from 'next/link'

interface MitraItem {
  id: number
  nama: string
  deskripsi: string
  logoUrl: string | null
  website: string
  urutan: number
}

function PlaceholderIcon() {
  return (
    <svg
      className="h-6 w-6 text-gray-300"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M3 21V7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14" />
      <path d="M3 10h18M10 21V10" />
    </svg>
  )
}

function ArrowUpRightIcon() {
  return (
    <svg
      className="h-3 w-3"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M7 17L17 7M7 7h10v10" />
    </svg>
  )
}

function ArrowRightIcon() {
  return (
    <svg
      className="h-3.5 w-3.5"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <line x1="5" y1="12" x2="19" y2="12" />
      <polyline points="12 5 19 12 12 19" />
    </svg>
  )
}

function MitraCard({ item }: { item: MitraItem }) {
  return (
    <div className="group flex flex-col items-center gap-2.5 rounded-xl border border-gray-100 bg-white p-5 text-center transition-colors hover:border-gray-200">
      {/* Logo / placeholder */}
      {item.logoUrl ? (
        <div className="relative h-12 w-12 overflow-hidden rounded-lg bg-gray-50">
          <Image
            src={item.logoUrl}
            alt={item.nama}
            fill
            className="object-contain p-1"
          />
        </div>
      ) : (
        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gray-50">
          <PlaceholderIcon />
        </div>
      )}

      {/* Nama */}
      <h3 className="line-clamp-2 text-[13px] font-medium leading-snug text-gray-900">
        {item.nama}
      </h3>

      {/* Deskripsi */}
      {item.deskripsi && (
        <p className="line-clamp-2 text-xs leading-relaxed text-gray-400">
          {item.deskripsi}
        </p>
      )}

      {/* Link website */}
      {item.website && (
        <Link
          href={item.website}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-auto inline-flex items-center gap-1 text-[11px] font-medium tracking-[.04em] text-nu-green-600 hover:underline"
        >
          Kunjungi
          <ArrowUpRightIcon />
        </Link>
      )}
    </div>
  )
}

export default function MitraIndustriSection() {
  const [items, setItems] = useState<MitraItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchMitra() {
      try {
        const res = await fetch('/api/mitra')
        const data = await res.json()
        if (data.success) {
          setItems(data.items)
        }
      } catch (error) {
        console.error('Error fetching mitra:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchMitra()
  }, [])

  if (loading) {
    return (
      <section className="bg-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-nu-green-600 border-t-transparent" />
          <p className="mt-2 text-sm text-gray-400">Memuat mitra industri...</p>
        </div>
      </section>
    )
  }

  if (!items || items.length === 0) {
    return (
      <section className="bg-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h2 className="mb-2 text-2xl font-bold text-gray-900">Mitra Industri</h2>
          <p className="text-gray-400 text-sm">
            Belum ada mitra industri. Tambahkan di admin panel.
          </p>
        </div>
      </section>
    )
  }

  // Ambil 5 item pertama saja
  const displayItems = items.slice(0, 5)

  return (
    <section className="bg-white py-12" aria-labelledby="mitra-heading">
      <div className="container mx-auto px-4">

        {/* ── Header ── */}
        <div className="mb-8">
          <p className="mb-1.5 flex items-center gap-2 text-[11px] font-medium uppercase tracking-[.12em] text-gray-400">
            <span className="block h-px w-5 bg-gray-300" aria-hidden="true" />
            Kerjasama
          </p>
          <h2
            id="mitra-heading"
            className="mb-1.5 text-2xl font-bold text-gray-900"
          >
            Mitra Industri
          </h2>
          <p className="max-w-lg text-sm leading-relaxed text-gray-500">
            Perusahaan mitra yang bekerja sama dengan SMK Ma&apos;arif NU 01
            Karangkobar
          </p>
        </div>

        {/* ── Grid mitra ── */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {displayItems.map((item) => (
            <MitraCard key={item.id} item={item} />
          ))}
        </div>

        {/* ── Tautan ke halaman HUMAS ── */}
        <div className="mt-8 flex items-center gap-3">
          <span className="h-px flex-1 bg-gray-100" aria-hidden="true" />
          <Link
            href="/humas"
            className="inline-flex items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-[13px] font-medium text-gray-500 transition-colors hover:border-gray-300 hover:text-gray-800"
          >
            Lihat semua mitra industri
            <ArrowRightIcon />
          </Link>
          <span className="h-px flex-1 bg-gray-100" aria-hidden="true" />
        </div>

      </div>
    </section>
  )
}
