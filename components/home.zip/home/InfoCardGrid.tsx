import Link from 'next/link'

interface InfoCard {
  id: string
  judul: string
  deskripsi: string
  href: string
}

const cards: InfoCard[] = [
  {
    id: 'ppdb',
    judul: 'PPDB Online',
    deskripsi: 'Daftar sebagai peserta didik baru secara online. Mudah, cepat, dan tanpa antri.',
    href: '/ppdb',
  },
  {
    id: 'program-keahlian',
    judul: 'Program Keahlian',
    deskripsi: 'Tiga program unggulan: TBSM, TJKT, dan AKL. Pilih sesuai minat dan bakat kamu.',
    href: '/program-keahlian',
  },
  {
    id: 'galeri',
    judul: 'Galeri Kegiatan',
    deskripsi: 'Lihat foto dan video kegiatan sekolah, prestasi siswa, dan momen berkesan lainnya.',
    href: '/galeri',
  },
  {
    id: 'mitra-industri',
    judul: 'Mitra Industri',
    deskripsi: 'Jaringan mitra industri yang mendukung PKL dan penempatan kerja lulusan kami.',
    href: '/humas',
  },
]

// Icon sederhana per card — cocok dengan konteks masing-masing
const cardIcons: Record<string, React.ReactNode> = {
  ppdb: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M19 8v6M22 11h-6" />
    </svg>
  ),
  'program-keahlian': (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
    </svg>
  ),
  galeri: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
      <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
      <circle cx="9" cy="9" r="2" />
      <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
    </svg>
  ),
  'mitra-industri': (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  ),
}

export default function InfoCardGrid() {
  return (
    <section
      aria-labelledby="info-card-grid-heading"
      className="py-10 bg-nu-green-800"
    >
      <div className="container mx-auto px-4">
        <h2 id="info-card-grid-heading" className="sr-only">
          Informasi Utama Sekolah
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {cards.map((card) => (
            <Link
              key={card.id}
              href={card.href}
              className="group relative flex flex-col items-start p-5 rounded-2xl bg-nu-green-700/50 border border-nu-green-600/40 hover:bg-nu-green-700 hover:border-nu-green-500/60 transition-all duration-200 hover:-translate-y-0.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-nu-green-300"
              aria-label={`${card.judul} — ${card.deskripsi}`}
            >
              {/* Icon badge */}
              <div className="mb-3 flex h-9 w-9 items-center justify-center rounded-xl bg-nu-green-500/30 text-nu-green-200 group-hover:bg-nu-green-500/50 transition-colors duration-200">
                {cardIcons[card.id]}
              </div>

              <h3 className="text-sm font-semibold text-white leading-snug mb-1.5">
                {card.judul}
              </h3>

              <p className="text-xs text-nu-green-200/70 leading-relaxed hidden sm:block flex-1">
                {card.deskripsi}
              </p>

              <span
                className="mt-3 text-nu-green-400 group-hover:text-nu-green-200 group-hover:translate-x-1 transition-all duration-150 hidden sm:block text-sm"
                aria-hidden="true"
              >
                →
              </span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
